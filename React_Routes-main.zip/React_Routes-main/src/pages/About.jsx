// src/pages/About.jsx
const About = () => {
    return (
      <div>
        <h1>About Us</h1>
        <p>We provide fast delivery services worldwide.</p>
      </div>
    );
  };
  
  export default About;