// src/pages/Home.jsx
const Home = () => {
    return (
      <div>
        <h1>Welcome to the E Commers Website</h1>
        <p>Find the best deals here. Order Now.</p>
      </div>
    );
  };
  
  export default Home;